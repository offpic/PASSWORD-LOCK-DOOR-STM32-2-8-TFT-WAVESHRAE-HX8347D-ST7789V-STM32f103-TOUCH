/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd_driver.h"
//#include "Touch.h"
#include "XPT2046.h"
#include "stdio.h"

#include "008_Open_Sans_Bold.h"
#include "009_Open_Sans_Bold.h"
#include "010_Open_Sans_Bold.h"
#include "012_Open_Sans_Bold.h"
#include "014_Open_Sans_Bold.h"
#include "016_Open_Sans_Bold.h"
#include "018_Open_Sans_Bold.h"
#include "020_Open_Sans_Bold.h"
#include "022_Open_Sans_Bold.h"
#include "024_Open_Sans_Bold.h"
#include "026_Open_Sans_Bold.h"
#include "028_Open_Sans_Bold.h"
#include "036_Open_Sans_Bold.h"
#include "048_Open_Sans_Bold.h"
#include "072_Open_Sans_Bold.h"
#include "096_Open_Sans_Bold.h"
#include "112_Open_Sans_Bold.h"
#include "128_Open_Sans_Bold.h"


#define TP_PRESS_DOWN           0x80
#define TP_PRESSED              0x40

typedef struct {
	uint16_t hwXpos0;
	uint16_t hwYpos0;
	uint16_t hwXpos;
	uint16_t hwYpos;
	uint8_t chStatus;
	uint8_t chType;
	short iXoff;
	short iYoff;
	float fXfac;
	float fYfac;
} tp_dev_t;


static tp_dev_t s_tTouch;

char str1[20];
char pass[4];
char pass1[4]={'1','2','3','4'};//change PASSWORD
char str2[20];
int i=0;

char str[20];
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t tp_scan(uint8_t chCoordType)
{
	s_tTouch.fXfac = (float)(LCD_WIDTH - 40) / (int16_t)(240 - 1758);
	s_tTouch.iXoff = (LCD_WIDTH - s_tTouch.fXfac * (240 + 1758)) / 2;

	s_tTouch.fYfac = (float)(LCD_HEIGHT - 40) / (int16_t)(267 - 1826);
	s_tTouch.iYoff = (LCD_HEIGHT - s_tTouch.fYfac * (267 + 1826)) / 2;

	if (!(__XPT2046_IRQ_READ())) {
		if (chCoordType) {
			xpt2046_twice_read_xy(&s_tTouch.hwXpos, &s_tTouch.hwYpos);
		} else if (xpt2046_twice_read_xy(&s_tTouch.hwXpos, &s_tTouch.hwYpos)) {
			s_tTouch.hwXpos = s_tTouch.fXfac * s_tTouch.hwXpos + s_tTouch.iXoff;
			s_tTouch.hwYpos = s_tTouch.fYfac * s_tTouch.hwYpos + s_tTouch.iYoff;
		}
		if (0 == (s_tTouch.chStatus & TP_PRESS_DOWN)) {
			s_tTouch.chStatus = TP_PRESS_DOWN | TP_PRESSED;
			s_tTouch.hwXpos0 = s_tTouch.hwXpos;
			s_tTouch.hwYpos0 = s_tTouch.hwYpos;
		}

	} else {
		if (s_tTouch.chStatus & TP_PRESS_DOWN) {
			s_tTouch.chStatus &= ~(1 << 7);
		} else {
			s_tTouch.hwXpos0 = 0;
			s_tTouch.hwYpos0 = 0;
			s_tTouch.hwXpos = 0xffff;
			s_tTouch.hwYpos = 0xffff;
		}
	}

	return (s_tTouch.chStatus & TP_PRESS_DOWN);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI2_Init();
  /* USER CODE BEGIN 2 */
	lcd_init();
//	lcd_clear_screen(GREEN);

//    tp_adjust();
//	tp_dialog();

	lcd_clear_screen(WHITE);

	lcd_draw_rect(7,3,222,70,BLACK);
	lcd_draw_rect(8,4,220,68,BLACK);
	lcd_draw_rect(9,5,218,66,BLACK);





	lcd_fill_rect(8,80,50,75,BLUE);
	LCD_Font(18, 130, "1", _Open_Sans_Bold_48, 1, BLACK);

	lcd_fill_rect(66,80,50,75,BLUE);
	LCD_Font(76, 130, "2", _Open_Sans_Bold_48, 1, BLACK);

	lcd_fill_rect(122,80,50,75,BLUE);
	LCD_Font(132, 130, "3", _Open_Sans_Bold_48, 1, BLACK);

	lcd_fill_rect(180,80,50,75,BLUE);
	LCD_Font(190, 130, "4", _Open_Sans_Bold_48, 1, BLACK);


	lcd_fill_rect(8,160,50,75,GREEN);
	LCD_Font(18, 210, "5", _Open_Sans_Bold_48, 1, BLACK);

	lcd_fill_rect(66,160,50,75,GREEN);
	LCD_Font(76, 210, "6", _Open_Sans_Bold_48, 1, BLACK);

	lcd_fill_rect(122,160,50,75,GREEN);
	LCD_Font(132, 210, "7", _Open_Sans_Bold_48, 1, BLACK);

	lcd_fill_rect(180,160,50,75,GREEN);
	LCD_Font(190, 210, "8", _Open_Sans_Bold_48, 1, BLACK);


	lcd_fill_rect(8,240,50,75,RED);
	LCD_Font(18, 290, "9", _Open_Sans_Bold_48, 1, BLACK);

	lcd_fill_rect(66,240,50,75,RED);
	LCD_Font(76, 290, "0", _Open_Sans_Bold_48, 1, BLACK);

	lcd_fill_rect(122,240,50,75,RED);
	LCD_Font(132, 300, "*", _Open_Sans_Bold_48, 1, BLACK);

	lcd_fill_rect(180,240,50,75,RED);
	LCD_Font(183, 290, "OK", _Open_Sans_Bold_28, 1, BLACK);

	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
		tp_scan(0);
		if (s_tTouch.chStatus & TP_PRESS_DOWN) {
			if (s_tTouch.hwXpos < LCD_WIDTH && s_tTouch.hwYpos < LCD_HEIGHT) {
				if (s_tTouch.hwXpos > (LCD_WIDTH - 40) && s_tTouch.hwYpos < 16) {
//					tp_dialog();
				} else {

					sprintf(str1, "%hd %hd", s_tTouch.hwXpos, s_tTouch.hwYpos);
					lcd_fill_rect(10,7,50,10,WHITE);
					lcd_display_string(10, 7, (const uint8_t *)str1, 12, BLACK);


				  	if(s_tTouch.hwXpos >=8 && s_tTouch.hwXpos<=58 && s_tTouch.hwYpos>=78 && s_tTouch.hwYpos<=150)
					{


	//			  		HAL_Delay(300);

	//
	//
	//

				  		if(i==0)
				  		{
				  			pass[0]='1';
				  			LCD_Font(60, 55, "1", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='1';
				  			LCD_Font(90, 55, "1", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='1';
				  			LCD_Font(120, 55, "1", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='1';
				  			LCD_Font(150, 55, "1", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}

					}

				  	if(s_tTouch.hwXpos >=64 && s_tTouch.hwXpos<=110 && s_tTouch.hwYpos>=78 && s_tTouch.hwYpos<=150)
					{

				  		if(i==0)
				  		{
				  			pass[0]='2';
				  			LCD_Font(60, 55, "2", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='2';
				  			LCD_Font(90, 55, "2", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='2';
				  			LCD_Font(120, 55, "2", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='2';
				  			LCD_Font(150, 55, "2", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}

					}

				  	if(s_tTouch.hwXpos >=122 && s_tTouch.hwXpos<=171 && s_tTouch.hwYpos>=78 && s_tTouch.hwYpos<=150)
					{

				  		if(i==0)
				  		{
				  			pass[0]='3';
				  			LCD_Font(60, 55, "3", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='3';
				  			LCD_Font(90, 55, "3", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='3';
				  			LCD_Font(120, 55, "3", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='3';
				  			LCD_Font(150, 55, "3", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}

					}

				  	if(s_tTouch.hwXpos >=180 && s_tTouch.hwXpos<=226 && s_tTouch.hwYpos>=78 && s_tTouch.hwYpos<=150)
					{

				  		if(i==0)
				  		{
				  			pass[0]='4';
				  			LCD_Font(60, 55, "4", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='4';
				  			LCD_Font(90, 55, "4", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='4';
				  			LCD_Font(120, 55, "4", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='4';
				  			LCD_Font(150, 55, "4", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}

					}


				  	if(s_tTouch.hwXpos >=8 && s_tTouch.hwXpos<=58 && s_tTouch.hwYpos>=150 && s_tTouch.hwYpos<=230)
					{


				  		if(i==0)
				  		{
				  			pass[0]='5';
				  			LCD_Font(60, 55, "5", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='5';
				  			LCD_Font(90, 55, "5", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='5';
				  			LCD_Font(120, 55, "5", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='5';
				  			LCD_Font(150, 55, "5", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}

					}

				  	if(s_tTouch.hwXpos >=64 && s_tTouch.hwXpos<=110 && s_tTouch.hwYpos>=150 && s_tTouch.hwYpos<=230)
					{

				  		if(i==0)
				  		{
				  			pass[0]='6';
				  			LCD_Font(60, 55, "6", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='6';
				  			LCD_Font(90, 55, "6", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='6';
				  			LCD_Font(120, 55, "6", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='6';
				  			LCD_Font(150, 55, "6", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}

					}

				  	if(s_tTouch.hwXpos >=120 && s_tTouch.hwXpos<=170 && s_tTouch.hwYpos>=150 && s_tTouch.hwYpos<=230)
					{


				  		if(i==0)
				  		{
				  			pass[0]='7';
				  			LCD_Font(60, 55, "7", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='7';
				  			LCD_Font(90, 55, "7", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='7';
				  			LCD_Font(120, 55, "7", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='7';
				  			LCD_Font(150, 55, "7", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}

					}

				  	if(s_tTouch.hwXpos >=177 && s_tTouch.hwXpos<=222 && s_tTouch.hwYpos>=150 && s_tTouch.hwYpos<=230)
					{



				  		if(i==0)
				  		{
				  			pass[0]='8';
				  			LCD_Font(60, 55, "8", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='8';
				  			LCD_Font(90, 55, "8", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='8';
				  			LCD_Font(120, 55, "8", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='8';
				  			LCD_Font(150, 55, "8", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}

					}

				  	if(s_tTouch.hwXpos >=8 && s_tTouch.hwXpos<=58 && s_tTouch.hwYpos>=230 && s_tTouch.hwYpos<=307)
					{


				  		if(i==0)
				  		{
				  			pass[0]='9';
				  			LCD_Font(60, 55, "9", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='9';
				  			LCD_Font(90, 55, "9", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='9';
				  			LCD_Font(120, 55, "9", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='9';
				  			LCD_Font(150, 55, "9", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}

					}

				  	if(s_tTouch.hwXpos >=61 && s_tTouch.hwXpos<=110 && s_tTouch.hwYpos>=230 && s_tTouch.hwYpos<=307)
					{



				  		if(i==0)
				  		{
				  			pass[0]='0';
				  			LCD_Font(60, 55, "0", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==1)
				  		{
				  			pass[1]='0';
				  			LCD_Font(90, 55, "0", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==2)
				  		{
				  			pass[2]='0';
				  			LCD_Font(120, 55, "0", _Open_Sans_Bold_48, 1, BLACK);
				  		}
				  		else if(i==3)
				  		{
				  			pass[3]='0';
				  			LCD_Font(150, 55, "0", _Open_Sans_Bold_48, 1, BLACK);
				  		}

				  		HAL_Delay(300);
				  		i++;

				  		if(i==4)
				  		{
				  			i=0;
				  		}


					}

				  	if(s_tTouch.hwXpos >=116 && s_tTouch.hwXpos<=166 && s_tTouch.hwYpos>=230 && s_tTouch.hwYpos<=307)
					{

			  			lcd_fill_rect(10,6,216,64,WHITE);

			  			i=0;

					}

				  	if(s_tTouch.hwXpos >=177 && s_tTouch.hwXpos<=225 && s_tTouch.hwYpos>=230 && s_tTouch.hwYpos<=307)
					{

				  		if(pass[0]==pass1[0]&&pass[1]==pass1[1]&&pass[2]==pass1[2]&&pass[3]==pass1[3])
				  		{
				  			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

				  			HAL_Delay(1000);

				  			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
				  			lcd_fill_rect(10,6,216,64,WHITE);
				  		}

				  		else
				  		{
				  			lcd_fill_rect(10,6,216,64,WHITE);

				  			LCD_Font(12, 55, "Wrong Password", _Open_Sans_Bold_24, 1, BLACK);

				  			lcd_fill_rect(10,6,216,64,WHITE);


				  			i=0;
				  		}

					}



				}
			}
		}
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_RST_Pin|LCD_DC_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_BL_Pin|XPT2046_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RST_Pin LCD_DC_Pin */
  GPIO_InitStruct.Pin = LCD_RST_Pin|LCD_DC_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_BL_Pin XPT2046_CS_Pin */
  GPIO_InitStruct.Pin = LCD_BL_Pin|XPT2046_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : XPT2046_IRQ_Pin */
  GPIO_InitStruct.Pin = XPT2046_IRQ_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(XPT2046_IRQ_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LCD_CS_Pin */
  GPIO_InitStruct.Pin = LCD_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LCD_CS_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
